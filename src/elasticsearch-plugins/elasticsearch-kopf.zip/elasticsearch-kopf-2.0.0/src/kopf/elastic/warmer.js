function Warmer(id, index, body) {
  this.id = id;
  this.index = index;
  this.source = body.source;
  this.types = body.types;
}
